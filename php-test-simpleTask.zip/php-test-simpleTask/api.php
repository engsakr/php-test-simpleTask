<?php
include_once 'include/waseet.php';




insert::in_videos(19,16,'c','f','hqdefault.jpg','youtube','fff','2014-11-13 03:15:05','1',
 'f' , 'f' , 'f' , 'f' , 'f' , 'f' , 'f' , 'f'  , 'f' , 'f' , 'f' , 'f' , 'f');






